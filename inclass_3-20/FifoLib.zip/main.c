#include "fifo.h"
#include "actors.h"

int main()
{
	fifo_t input1;
	fifo_t input2;
	fifo_t output1;
	init_fifo(&input1);
	init_fifo(&input2);
	init_fifo(&output1);
	// create two initial tokens with value 10
	put_fifo(&input1, 10);
	put_fifo(&input2, 10);
	// iterate the system schedule 100 times
	for (unsigned i=0; i<100; i++)
	{
		actor_mul(&input1,&input2,&output1);
	}
	// after this completes, the output1 queue
	// will contain a single token with value 100
	return 0;
}
